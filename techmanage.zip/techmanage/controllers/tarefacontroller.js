const { Tarefa, Projeto } = require('../models');

// GET - Listar todas as tarefas
const getAllTarefas = async (req, res) => {
  try {
    const tarefas = await Tarefa.findAll({
      include: [{
        model: Projeto,
        as: 'projeto',
        attributes: ['id', 'titulo']
      }]
    });
    
    res.json({
      success: true,
      data: tarefas,
      message: 'Tarefas listadas com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao listar tarefas',
      error: error.message
    });
  }
};

// GET - Buscar tarefa por ID
const getTarefaById = async (req, res) => {
  try {
    const { id } = req.params;
    const tarefa = await Tarefa.findByPk(id, {
      include: [{
        model: Projeto,
        as: 'projeto',
        attributes: ['id', 'titulo']
      }]
    });
    
    if (!tarefa) {
      return res.status(404).json({
        success: false,
        message: 'Tarefa não encontrada'
      });
    }
    
    res.json({
      success: true,
      data: tarefa,
      message: 'Tarefa encontrada com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar tarefa',
      error: error.message
    });
  }
};

// POST - Criar tarefa
const createTarefa = async (req, res) => {
  try {
    const { titulo, status, prioridade, id_projeto } = req.body;
    
    if (!titulo || !id_projeto) {
      return res.status(400).json({
        success: false,
        message: 'Título e ID do projeto são obrigatórios'
      });
    }
    
    // Verificar se projeto existe
    const projeto = await Projeto.findByPk(id_projeto);
    if (!projeto) {
      return res.status(404).json({
        success: false,
        message: 'Projeto não encontrado'
      });
    }
    
    const tarefa = await Tarefa.create({
      titulo,
      status: status || 'pendente',
      prioridade: prioridade || 'media',
      id_projeto
    });
    
    res.status(201).json({
      success: true,
      data: tarefa,
      message: 'Tarefa criada com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao criar tarefa',
      error: error.message
    });
  }
};

// PUT - Atualizar tarefa
const updateTarefa = async (req, res) => {
  try {
    const { id } = req.params;
    const { titulo, status, prioridade, id_projeto } = req.body;
    
    const tarefa = await Tarefa.findByPk(id);
    
    if (!tarefa) {
      return res.status(404).json({
        success: false,
        message: 'Tarefa não encontrada'
      });
    }
    
    // Verificar se projeto existe (se for atualizar)
    if (id_projeto) {
      const projeto = await Projeto.findByPk(id_projeto);
      if (!projeto) {
        return res.status(404).json({
          success: false,
          message: 'Projeto não encontrado'
        });
      }
    }
    
    await tarefa.update({
      titulo,
      status,
      prioridade,
      id_projeto
    });
    
    res.json({
      success: true,
      data: tarefa,
      message: 'Tarefa atualizada com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar tarefa',
      error: error.message
    });
  }
};

// DELETE - Deletar tarefa
const deleteTarefa = async (req, res) => {
  try {
    const { id } = req.params;
    const tarefa = await Tarefa.findByPk(id);
    
    if (!tarefa) {
      return res.status(404).json({
        success: false,
        message: 'Tarefa não encontrada'
      });
    }
    
    await tarefa.destroy();
    
    res.json({
      success: true,
      message: 'Tarefa deletada com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao deletar tarefa',
      error: error.message
    });
  }
};

module.exports = {
  getAllTarefas,
  getTarefaById,
  createTarefa,
  updateTarefa,
  deleteTarefa
};