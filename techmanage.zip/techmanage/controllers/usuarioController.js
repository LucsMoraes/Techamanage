    const { Usuario } = require('../models');
const bcrypt = require('bcryptjs');

// GET - Listar todos os usuários
const getAllUsuarios = async (req, res) => {
  try {
    const usuarios = await Usuario.findAll({
      attributes: { exclude: ['senha'] }
    });
    
    res.json({
      success: true,
      data: usuarios,
      message: 'Usuários listados com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao listar usuários',
      error: error.message
    });
  }
};

// GET - Buscar usuário por ID
const getUsuarioById = async (req, res) => {
  try {
    const { id } = req.params;
    const usuario = await Usuario.findByPk(id, {
      attributes: { exclude: ['senha'] }
    });
    
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }
    
    res.json({
      success: true,
      data: usuario,
      message: 'Usuário encontrado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar usuário',
      error: error.message
    });
  }
};

// POST - Criar usuário
const createUsuario = async (req, res) => {
  try {
    const { nome, email, senha, perfil } = req.body;
    
    if (!nome || !email || !senha) {
      return res.status(400).json({
        success: false,
        message: 'Nome, email e senha são obrigatórios'
      });
    }
    
    // Verificar se email já existe
    const usuarioExistente = await Usuario.findOne({ where: { email } });
    if (usuarioExistente) {
      return res.status(400).json({
        success: false,
        message: 'Email já cadastrado'
      });
    }
    
    // Criptografar senha
    const senhaCriptografada = await bcrypt.hash(senha, 10);
    
    const novoUsuario = await Usuario.create({
      nome,
      email,
      senha: senhaCriptografada,
      perfil: perfil || 'usuario'
    });
    
    // Não retornar senha
    const usuarioResponse = { ...novoUsuario.toJSON() };
    delete usuarioResponse.senha;
    
    res.status(201).json({
      success: true,
      data: usuarioResponse,
      message: 'Usuário criado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao criar usuário',
      error: error.message
    });
  }
};

// PUT - Atualizar usuário
const updateUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, email, senha, perfil } = req.body;
    
    const usuario = await Usuario.findByPk(id);
    
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }
    
    // Verificar se email já existe em outro usuário
    if (email && email !== usuario.email) {
      const emailExistente = await Usuario.findOne({ where: { email } });
      if (emailExistente) {
        return res.status(400).json({
          success: false,
          message: 'Email já está em uso'
        });
      }
    }
    
    // Preparar dados para atualização
    const dadosAtualizacao = {};
    if (nome) dadosAtualizacao.nome = nome;
    if (email) dadosAtualizacao.email = email;
    if (perfil) dadosAtualizacao.perfil = perfil;
    
    // Criptografar nova senha se for fornecida
    if (senha) {
      dadosAtualizacao.senha = await bcrypt.hash(senha, 10);
    }
    
    await usuario.update(dadosAtualizacao);
    
    // Buscar usuário atualizado sem senha
    const usuarioAtualizado = await Usuario.findByPk(id, {
      attributes: { exclude: ['senha'] }
    });
    
    res.json({
      success: true,
      data: usuarioAtualizado,
      message: 'Usuário atualizado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar usuário',
      error: error.message
    });
  }
};

// DELETE - Deletar usuário
const deleteUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const usuario = await Usuario.findByPk(id);
    
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }
    
    await usuario.destroy();
    
    res.json({
      success: true,
      message: 'Usuário deletado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao deletar usuário',
      error: error.message
    });
  }
};

module.exports = {
  getAllUsuarios,
  getUsuarioById,
  createUsuario,
  updateUsuario,
  deleteUsuario
};