const { Projeto, Usuario } = require('../models');

// GET - Listar todos os projetos
const getAllProjetos = async (req, res) => {
  try {
    const projetos = await Projeto.findAll({
      include: [{
        model: Usuario,
        as: 'usuario',
        attributes: ['id', 'nome', 'email']
      }]
    });
    
    res.json({
      success: true,
      data: projetos,
      message: 'Projetos listados com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao listar projetos',
      error: error.message
    });
  }
};

// GET - Buscar projeto por ID
const getProjetoById = async (req, res) => {
  try {
    const { id } = req.params;
    const projeto = await Projeto.findByPk(id, {
      include: [{
        model: Usuario,
        as: 'usuario',
        attributes: ['id', 'nome', 'email']
      }]
    });
    
    if (!projeto) {
      return res.status(404).json({
        success: false,
        message: 'Projeto não encontrado'
      });
    }
    
    res.json({
      success: true,
      data: projeto,
      message: 'Projeto encontrado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar projeto',
      error: error.message
    });
  }
};

// POST - Criar projeto
const createProjeto = async (req, res) => {
  try {
    const { titulo, descricao, data_inicio, data_fim, id_usuario } = req.body;
    
    if (!titulo || !id_usuario) {
      return res.status(400).json({
        success: false,
        message: 'Título e ID do usuário são obrigatórios'
      });
    }
    
    // Verificar se usuário existe
    const usuario = await Usuario.findByPk(id_usuario);
    if (!usuario) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }
    
    const projeto = await Projeto.create({
      titulo,
      descricao,
      data_inicio,
      data_fim,
      id_usuario
    });
    
    res.status(201).json({
      success: true,
      data: projeto,
      message: 'Projeto criado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao criar projeto',
      error: error.message
    });
  }
};

// PUT - Atualizar projeto
const updateProjeto = async (req, res) => {
  try {
    const { id } = req.params;
    const { titulo, descricao, data_inicio, data_fim, id_usuario } = req.body;
    
    const projeto = await Projeto.findByPk(id);
    
    if (!projeto) {
      return res.status(404).json({
        success: false,
        message: 'Projeto não encontrado'
      });
    }
    
    // Verificar se usuário existe (se for atualizar)
    if (id_usuario) {
      const usuario = await Usuario.findByPk(id_usuario);
      if (!usuario) {
        return res.status(404).json({
          success: false,
          message: 'Usuário não encontrado'
        });
      }
    }
    
    await projeto.update({
      titulo,
      descricao,
      data_inicio,
      data_fim,
      id_usuario
    });
    
    res.json({
      success: true,
      data: projeto,
      message: 'Projeto atualizado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar projeto',
      error: error.message
    });
  }
};

// DELETE - Deletar projeto
const deleteProjeto = async (req, res) => {
  try {
    const { id } = req.params;
    const projeto = await Projeto.findByPk(id);
    
    if (!projeto) {
      return res.status(404).json({
        success: false,
        message: 'Projeto não encontrado'
      });
    }
    
    await projeto.destroy();
    
    res.json({
      success: true,
      message: 'Projeto deletado com sucesso'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Erro ao deletar projeto',
      error: error.message
    });
  }
};

module.exports = {
  getAllProjetos,
  getProjetoById,
  createProjeto,
  updateProjeto,
  deleteProjeto
};