const sequelize = require('./src/database');
const Usuario = require('./src/models/Usuario');

sequelize.sync({ alter: true })
  .then(() => {
    console.log('Tabelas sincronizadas com sucesso!');
  })
  .catch(err => console.error('Erro ao sincronizar tabelas:', err));
