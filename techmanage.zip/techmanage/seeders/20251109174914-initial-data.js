'use strict';
const bcrypt = require('bcryptjs');

module.exports = {
  async up(queryInterface, Sequelize) {
    // 1. INSERIR USUÁRIOS
    await queryInterface.bulkInsert('Users', [
      {
        nome: 'Administrador Sistema',
        email: 'admin@techmanage.com',
        senha: await bcrypt.hash('123456', 10),
        perfil: 'admin',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        nome: 'João Silva',
        email: 'joao@techmanage.com',
        senha: await bcrypt.hash('123456', 10),
        perfil: 'gerente',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        nome: 'Maria Santos',
        email: 'maria@techmanage.com',
        senha: await bcrypt.hash('123456', 10),
        perfil: 'usuario',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        nome: 'Carlos Oliveira',
        email: 'carlos@techmanage.com',
        senha: await bcrypt.hash('123456', 10),
        perfil: 'usuario',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});

    // 2. INSERIR PROJETOS
    await queryInterface.bulkInsert('Projects', [
      {
        titulo: 'Sistema de Gestão Interna',
        descricao: 'Desenvolvimento do sistema TechManage para controle de projetos e tarefas da empresa',
        data_inicio: new Date('2024-01-15'),
        data_fim: new Date('2024-06-30'),
        id_usuario: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Migração para Cloud AWS',
        descricao: 'Transferir toda a infraestrutura local para nuvem AWS com alta disponibilidade',
        data_inicio: new Date('2024-02-01'),
        data_fim: new Date('2024-08-15'),
        id_usuario: 2,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Desenvolvimento App Mobile',
        descricao: 'Criar aplicativo mobile para acompanhamento de projetos em tempo real',
        data_inicio: new Date('2024-03-10'),
        data_fim: new Date('2024-09-20'),
        id_usuario: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});

    // 3. INSERIR TAREFAS
    await queryInterface.bulkInsert('Tasks', [
      {
        titulo: 'Criar modelo de dados do sistema',
        status: 'concluido',
        prioridade: 'alta',
        id_projeto: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Desenvolver API REST completa',
        status: 'em_andamento',
        prioridade: 'alta',
        id_projeto: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Criar interface do usuário',
        status: 'pendente',
        prioridade: 'media',
        id_projeto: 1,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Configurar servidores EC2 na AWS',
        status: 'em_andamento',
        prioridade: 'alta',
        id_projeto: 2,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Migrar banco de dados para RDS',
        status: 'pendente',
        prioridade: 'alta',
        id_projeto: 2,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Projetar interface do app',
        status: 'pendente',
        prioridade: 'media',
        id_projeto: 3,
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        titulo: 'Configurar ambiente de desenvolvimento',
        status: 'concluido',
        prioridade: 'baixa',
        id_projeto: 3,
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ], {});
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Tasks', null, {});
    await queryInterface.bulkDelete('Projects', null, {});
    await queryInterface.bulkDelete('Users', null, {});
  }
};