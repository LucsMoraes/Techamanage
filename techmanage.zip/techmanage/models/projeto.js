module.exports = (sequelize, DataTypes) => {
  const Projeto = sequelize.define('Projeto', {
    titulo: DataTypes.STRING,
    descricao: DataTypes.TEXT,
    data_inicio: DataTypes.DATE,
    data_fim: DataTypes.DATE
  }, {
    tableName: 'Projects'  // ← TABELA NO BANCO
  });

  Projeto.associate = function(models) {
    Projeto.belongsTo(models.Usuario, { foreignKey: 'id_usuario', as: 'usuario' });
    Projeto.hasMany(models.Tarefa, { foreignKey: 'id_projeto', as: 'tarefas' });
  };
  
  return Projeto;
};