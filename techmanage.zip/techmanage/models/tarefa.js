module.exports = (sequelize, DataTypes) => {
  const Tarefa = sequelize.define('Tarefa', {
    titulo: DataTypes.STRING,
    status: DataTypes.STRING,
    prioridade: DataTypes.STRING
  }, {
    tableName: 'Tasks'  // ← TABELA NO BANCO
  });

  Tarefa.associate = function(models) {
    Tarefa.belongsTo(models.Projeto, { foreignKey: 'id_projeto', as: 'projeto' });
  };
  
  return Tarefa;
};