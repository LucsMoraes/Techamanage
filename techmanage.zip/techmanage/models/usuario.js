module.exports = (sequelize, DataTypes) => {
  const Usuario = sequelize.define('Usuario', {
    nome: DataTypes.STRING,
    email: DataTypes.STRING,
    senha: DataTypes.STRING,
    perfil: DataTypes.STRING
  }, {
    tableName: 'Users'  // ← TABELA NO BANCO
  });

  Usuario.associate = function(models) {
    Usuario.hasMany(models.Projeto, { foreignKey: 'id_usuario', as: 'projetos' });
  };
  
  return Usuario;
};