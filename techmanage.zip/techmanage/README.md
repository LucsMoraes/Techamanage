# 🚀 TechManage - Sistema de Gestão de Projetos

Sistema CRUD completo para gestão de usuários, projetos e tarefas.

## 📋 Funcionalidades

- ✅ **Gestão de Usuários** - CRUD completo
- ✅ **Gestão de Projetos** - Com datas e responsáveis
- ✅ **Gestão de Tarefas** - Com status e prioridades
- ✅ **Relacionamentos** - Usuários → Projetos → Tarefas
- ✅ **API REST** - Endpoints JSON

## 🛠 Tecnologias

- **Backend:** Node.js, Express.js
- **ORM:** Sequelize
- **Banco:** MySQL
- **Autenticação:** bcryptjs

## 🚀 Instalação

1. **Clone o repositório:**
```bash
git clone <url-do-repositorio>
cd techmanage