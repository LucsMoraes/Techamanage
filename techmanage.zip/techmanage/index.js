const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Importar routes
const routes = require('./routes');

// Importar models - O Sequelize JÁ tem a conexão configurada
const { Usuario, Projeto, Tarefa } = require('./models');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas principais
app.use('/api', routes);

// Rota de boas-vindas
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '🚀 API TechManage está funcionando!',
    timestamp: new Date().toISOString(),
    endpoints: {
      usuarios: '/api/usuarios',
      projetos: '/api/projetos', 
      tarefas: '/api/tarefas'
    }
  });
});

// Rota health check
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'API está saudável',
    timestamp: new Date().toISOString()
  });
});

// Sincronizar banco e iniciar servidor
async function startServer() {
  try {
    // Testar conexão com o banco
    await Usuario.sequelize.authenticate();
    console.log('✅ Conexão com o banco estabelecida com sucesso.');

// NÃO sincronizar - as tabelas já existem
// await Usuario.sequelize.sync({ 
//   force: false,
//   alter: true
// });
console.log('✅ Tabelas já existem no banco.');
    console.log('✅ Modelos sincronizados com o banco.');

    // Iniciar servidor
    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando na porta ${PORT}`);
      console.log(`📍 URL: http://localhost:${PORT}/`);
    });

  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

// Iniciar aplicação
startServer();