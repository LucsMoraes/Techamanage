const express = require('express');
const router = express.Router();

// Importar todas as rotas
const usuarioRoutes = require('./usuarioRoutes');
const projetoRoutes = require('./projetoRoutes');
const tarefaRoutes = require('./tarefaRoutes');

// Configurar rotas
router.use('/usuarios', usuarioRoutes);
router.use('/projetos', projetoRoutes);
router.use('/tarefas', tarefaRoutes);

// Rota de teste
router.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'API TechManage está funcionando!',
    endpoints: {
      usuarios: '/api/usuarios',
      projetos: '/api/projetos',
      tarefas: '/api/tarefas'
    }
  });
});

module.exports = router;