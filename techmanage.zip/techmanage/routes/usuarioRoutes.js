const express = require('express');
const router = express.Router();
const {
  getAllUsuarios,
  getUsuarioById,
  createUsuario,
  updateUsuario,
  deleteUsuario
} = require('../controllers/usuarioController');

// Rotas CRUD para usuários
router.get('/', getAllUsuarios);        // GET /usuarios - Listar todos
router.get('/:id', getUsuarioById);     // GET /usuarios/1 - Buscar por ID
router.post('/', createUsuario);        // POST /usuarios - Criar usuário
router.put('/:id', updateUsuario);      // PUT /usuarios/1 - Atualizar usuário
router.delete('/:id', deleteUsuario);   // DELETE /usuarios/1 - Deletar usuário

module.exports = router;