const express = require('express');
const router = express.Router();
const {
  getAllProjetos,
  getProjetoById,
  createProjeto,
  updateProjeto,
  deleteProjeto
} = require('../controllers/projetoController');

// Rotas CRUD para projetos
router.get('/', getAllProjetos);        // GET /projetos - Listar todos
router.get('/:id', getProjetoById);     // GET /projetos/1 - Buscar por ID
router.post('/', createProjeto);        // POST /projetos - Criar projeto
router.put('/:id', updateProjeto);      // PUT /projetos/1 - Atualizar projeto
router.delete('/:id', deleteProjeto);   // DELETE /projetos/1 - Deletar projeto

module.exports = router;