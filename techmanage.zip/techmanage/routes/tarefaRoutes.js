const express = require('express');
const router = express.Router();
const {
  getAllTarefas,
  getTarefaById,
  createTarefa,
  updateTarefa,
  deleteTarefa
} = require('../controllers/tarefaController');

// Rotas CRUD para tarefas
router.get('/', getAllTarefas);         // GET /tarefas - Listar todas
router.get('/:id', getTarefaById);      // GET /tarefas/1 - Buscar por ID
router.post('/', createTarefa);         // POST /tarefas - Criar tarefa
router.put('/:id', updateTarefa);       // PUT /tarefas/1 - Atualizar tarefa
router.delete('/:id', deleteTarefa);    // DELETE /tarefas/1 - Deletar tarefa

module.exports = router;